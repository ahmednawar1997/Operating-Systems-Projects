#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

struct arguments_struct{
    int firstIndex;
    int lastIndex;
    int *array;
};


void copySortedArray(int array[], int mergedArray[], int leftIndex, int rightIndex){
    int k = 0;
    int i;

    for(i = leftIndex; i <= rightIndex; i++){
        array[i] = mergedArray[k++];
    }
}

void merge(int array[], int leftIndex, int rightIndex, int middleIndex){
    int mergedArray[rightIndex - leftIndex + 1];

    int i = leftIndex;
    int j = middleIndex + 1;
    int k = 0;


    while(i <= middleIndex && j <= rightIndex){
        if(array[i]<=array[j]){
            mergedArray[k++] = array[i++];
        }
        else{
            mergedArray[k++] = array[j++];
        }
    }

    while(i <= middleIndex){
        mergedArray[k++] = array[i++];
    }
    while(j <= rightIndex){
        mergedArray[k++] = array[j++];
    }

    copySortedArray(array, mergedArray, leftIndex, rightIndex);
}

void *runThread(void *arguments){

    struct arguments_struct *args = arguments;
    mergeSort(args->array, args->firstIndex, args->lastIndex);
}


void mergeSort(int array[], int leftIndex, int rightIndex){

    if(rightIndex <= leftIndex)
        return;

    int middleIndex = (leftIndex + rightIndex) / 2;

    pthread_t thread1;
    struct arguments_struct args1;
    args1.firstIndex = leftIndex;
    args1.lastIndex = middleIndex;
    args1.array = array;

    pthread_create(&thread1, NULL, runThread, (void *)&args1);

    pthread_t thread2;
    struct arguments_struct args2;
    args2.firstIndex = middleIndex + 1;
    args2.lastIndex = rightIndex;
    args2.array = array;

    pthread_create(&thread2, NULL, runThread, (void *)&args2);

    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    merge(array,leftIndex, rightIndex, middleIndex);
}

void mergeSortSingleThread(int array[], int leftIndex, int rightIndex){

    if(rightIndex <= leftIndex)
        return;

    int middleIndex = (leftIndex + rightIndex) / 2;

    mergeSort(array, leftIndex, middleIndex);
    mergeSort(array, middleIndex + 1, rightIndex);

    merge(array,leftIndex, rightIndex, middleIndex);
}

void printArray(int array[], int length){
    int i;
    for(i = 0; i < length; i++){
        printf("%d ", array[i]);
    }
    printf("\n");
}

int readArrayFromFile(int array[]){
    int arrayLength, k = 0, bytesRead, num;
    FILE *fp = fopen("input.txt", "r");
    char line[256];
    if(fp == NULL) {
        printf("Error opening file\n");
    }

    fgets(line, 256, fp);
    sscanf(line, "%d\n", &arrayLength);

    fgets(line, 256, fp);
    char *line1 = line;
    while(sscanf(line1, "%d%n", &num,&bytesRead) > 0){
        array[k++] = num;
        line1 += bytesRead;

    }

    fclose(fp);
    return arrayLength;
}


int main()
{
    int arrayLength;
    clock_t start, end;
    double timeTaken;
    int array[100];

    arrayLength = readArrayFromFile(array);
    start = clock();

    mergeSort(array, 0, arrayLength-1);

    end = clock();
    timeTaken = ((double) (end - start));

    printf("Time taken: %.0lf\n",timeTaken);
    printArray(array, arrayLength);


    return 0;
}
