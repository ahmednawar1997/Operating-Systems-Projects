#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>


struct arguments_struct{
    int rowIndex1;
    int rowIndex2;
    int rowIndex3;
    int columnIndex1;
    int columnIndex2;
    int columnIndex3;
    int sum;

};

int array1[100][100];
int array2[100][100];
int resultArray1[100][100];
int resultArray2[100][100];
int rowLength1, columnLength1, rowLength2, columnLength2;


void printArray(int arrayNum, int rowLength, int columnLength){
    int i, j;
    if(arrayNum == 1){
        for(i = 0; i < rowLength1; i++){
            for(j = 0;j < columnLength1; j++){
                printf("%10d ",array1[i][j]);
            }
            printf("\n");
        }
    }else if (arrayNum == 2){
        for(i = 0; i < rowLength2; i++){
            for(j = 0;j < columnLength2; j++){
                printf("%10d",array2[i][j]);
            }
            printf("\n");
        }

    }else if(arrayNum == 3){
        for(i = 0; i < rowLength; i++){
            for(j = 0;j < columnLength; j++){
                printf("%10d",resultArray1[i][j]);
            }
            printf("\n");
        }
    }
}


void writeOutputToFile(double timeTaken1, double timeTaken2){
    writeArray1ToFile(timeTaken1);
    writeArray2ToFile(timeTaken2);
}

void writeArray1ToFile(double timeTaken){
    FILE *fp;

    fp=fopen("output.txt","w");
    int i ,j;
    for(i = 0; i < rowLength1; i++){
        for(j = 0; j < columnLength2; j++){
            fprintf(fp, "%d ",resultArray1[i][j]);
        }
        fprintf(fp, "\n");

    }
    fprintf(fp, "Time taken when each element is computed by a thread: %.0lf\n",timeTaken);
    fclose(fp);

}

void writeArray2ToFile(double timeTaken){
    FILE *fp;

    fp=fopen("output.txt","a");
    int i ,j;
    for(i = 0; i < rowLength1; i++){
        for(j = 0;j < columnLength2; j++){
            fprintf(fp,"%d ",resultArray2[i][j]);
        }
        fprintf(fp, "\n");
    }
    fprintf(fp, "Time taken when each row is computed by a thread: %.0lf\n",timeTaken);
    fclose(fp);

}



void readMatrixFromFile(){
    int i = 0, j = 0, bytesRead, num;
    char line[256];

    FILE *fp = fopen("input.txt", "r");
    if(fp == NULL)
        printf("Error opening file\n");

    fgets(line, 256, fp);
    char *line1 = line;
    sscanf(line1, "%d%n", &rowLength1, &bytesRead);
    line1 += bytesRead;
    sscanf(line1, "%d\n", &columnLength1);

    fgets(line, 256, fp);
    line1 = line;
    i = 0, j = 0;

    while(i < rowLength1){
        while(j < columnLength1 && sscanf(line1, "%d%n", &num, &bytesRead) > 0){
            array1[i][j++] = num;
            line1 += bytesRead;
        }
        fgets(line, 256, fp);
        line1 = line;

        i++;
        j = 0;
    }


    sscanf(line1, "%d%n", &rowLength2, &bytesRead);
    line1 += bytesRead;
    sscanf(line1, "%d", &columnLength2);

    fgets(line, 256, fp);
    line1 = line;
    i = 0, j = 0;
    while(i < rowLength2){
        while(j < columnLength2 && sscanf(line1, "%d%n", &num, &bytesRead) > 0){
            array2[i][j++] = num;
            line1 += bytesRead;
        }
        fgets(line, 256, fp);
        line1 = line;

        i++;
        j = 0;
    }

    fclose(fp);
}


void *runEachElementInAThread(void *arguments){
    struct arguments_struct *args = arguments;
    for(args->columnIndex1 = 0; args->columnIndex1 < columnLength1; args->columnIndex1++){
        args->sum += (array1[args->rowIndex1][args->columnIndex1] * array2[args->rowIndex2++][args->columnIndex2]);

    }
        resultArray1[args->rowIndex3][args->columnIndex3] = args->sum;
}

int executeElementInAThread(){
    int argsNum = 0, threadNum = 0;
    struct arguments_struct args;
    struct arguments_struct argsTemp[rowLength1 * columnLength2];
    pthread_t threads[rowLength1 * columnLength2];
    args.rowIndex1 = 0, args.columnIndex1 = 0, args.rowIndex2 = 0, args.columnIndex2 = 0, args.rowIndex3 = 0, args.columnIndex3 = 0, args.sum = 0;
    threadNum = 0;
    for(args.rowIndex1 = 0; args.rowIndex1 < rowLength1; args.rowIndex1++){
        for(args.columnIndex2 = 0; args.columnIndex2 < columnLength2; args.columnIndex2++){
            argsTemp[argsNum++] = args;
            pthread_create(&threads[threadNum++], NULL, runEachElementInAThread, (void *)&argsTemp[argsNum-1]);

            args.columnIndex3++;
            args.sum = 0;
            args.rowIndex2 = 0;

        }
        args.rowIndex3++;
        args.columnIndex3 = 0;
    }


    int k = 0;
    for(k = 0; k<rowLength1*columnLength2;k++){
        pthread_join(threads[k], NULL);

    }
}


void *runEachRowInAThread(void *arguments){
    struct arguments_struct *args = arguments;


    for(args->columnIndex2 = 0; args->columnIndex2 < columnLength2; args->columnIndex2++){
        for(args->columnIndex1 = 0; args->columnIndex1 < columnLength1; args->columnIndex1++){
            args->sum += (array1[args->rowIndex1][args->columnIndex1] * array2[args->rowIndex2++][args->columnIndex2]);

        }

        resultArray2[args->rowIndex3][args->columnIndex3] = args->sum;

        args->columnIndex3++;
        args->sum = 0;
        args->rowIndex2 = 0;
    }
}


int executeRowInAThread(){

    int argsNum = 0, threadNum = 0;
    struct arguments_struct args;
    struct arguments_struct argsTemp[rowLength1];
    pthread_t threads[rowLength1];
    args.rowIndex1 = 0, args.columnIndex1 = 0, args.rowIndex2 = 0, args.columnIndex2 = 0, args.rowIndex3 = 0, args.columnIndex3 = 0, args.sum = 0;

    for(args.rowIndex1 = 0; args.rowIndex1 < rowLength1; args.rowIndex1++){
        args.sum = 0;
        argsTemp[argsNum++] = args;
        pthread_create(&threads[threadNum++], NULL, runEachRowInAThread, (void *)&argsTemp[argsNum-1]);

        args.rowIndex3++;
        args.columnIndex3 = 0;
    }


    int k = 0;
    for(k = 0; k < rowLength1; k++){
        pthread_join(threads[k], NULL);

    }
}

int executeNormal(){
    int rowIndex1 = 0, columnIndex1 = 0, rowIndex2 = 0, columnIndex2 = 0, rowIndex3 = 0, columnIndex3 = 0, sum = 0, i = 0;

    for(rowIndex1 = 0; rowIndex1 < rowLength1; rowIndex1++){
        for(columnIndex2 = 0; columnIndex2 < columnLength2; columnIndex2++){
            for(columnIndex1 = 0; columnIndex1 < columnLength1; columnIndex1++){
                sum += (array1[rowIndex1][columnIndex1] * array2[rowIndex2++][columnIndex2]);

            }

            resultArray1[rowIndex3][columnIndex3++] = sum;
            sum = 0;
            rowIndex2 = 0;

        }
        rowIndex3++;
        columnIndex3 = 0;
    }

}

int main()
{
    clock_t start1, end1, start2, end2;
    double timeTaken1, timeTaken2;


    readMatrixFromFile();

    start1 = clock();
    executeElementInAThread();
    end1 = clock();

    start2 = clock();
    executeRowInAThread();
    end2 = clock();

    timeTaken1 = ((double) (end1 - start1));
    timeTaken2 = ((double) (end2 - start2));

    writeOutputToFile(timeTaken1, timeTaken2);
    printf("Done, check output.txt\n");
    printf("Result Array:\n");
    printArray(3, rowLength1, columnLength2);


    return 0;
}
